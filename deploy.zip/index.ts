exports.handler = async () => {
  // TODO implement
  const response = {
      statusCode: 200,
      body: JSON.stringify('It worked!!'),
  };
  return response;
};